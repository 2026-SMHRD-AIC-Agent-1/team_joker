"""진단 파이프라인 — '단계 함수' 5개 + 순차 실행.

RECON → ATTACK(R1: 스크리닝→취약기법 집중) → JUDGE → PATCH → ATTACK(R2: replay) → JUDGE → REPORT.

★ 함정③ 대비: 이 파일의 step_* 함수를 순차 경로(run_pipeline)와 그래프 경로(graph.py)가
  '똑같이' 쓴다. 로직이 한 곳이라 두 경로 결과가 자연히 일치하고, 그래프가 상태 키를 몰래
  버리면 trap03 이 잡는다.
- 각 step 은 새 state(dict 복사)를 반환한다 → 순차·그래프 양쪽에서 안전.
- 루프 종료조건은 round_no == 2 하드 고정.
"""

from __future__ import annotations

import hashlib

from joker.corpus.sampling import concentration_set, screening_set
from joker.deps import Deps
from joker.models import Report, Technique, Verdict
from joker.nodes.attack import build_context, run_attacks
from joker.nodes.judge import judge_attempts
from joker.nodes.patch import assemble_patch
from joker.nodes.recon import recon
from joker.nodes.report import build_report
from joker.state import RunState


def prompt_hash(text: str) -> str:
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def new_state(target_prompt: str, run_id: str = "run_local") -> RunState:
    return {
        "run_id": run_id,
        "target_prompt": target_prompt,
        "target_prompt_hash": prompt_hash(target_prompt),
        "round_no": 1,
        "attempts": [],
    }


# ── 단계 함수 (pipeline / graph 공용) ─────────────────────
def step_recon(state: RunState, deps: Deps) -> RunState:
    return recon(state, deps)  # recon 은 이미 새 dict 를 반환한다


def step_inconclusive(state: RunState, deps: Deps | None = None) -> RunState:
    """함정②: 값 자산 0개 → 등급 없이 종료."""
    new: RunState = dict(state)  # type: ignore[assignment]
    new["attempts"] = []
    new["vulnerable_techniques"] = []
    new["r1_attack_ids"] = []
    new["patched_prompt"] = None
    new["applied_patterns"] = []
    new["report"] = Report(
        grade=None, inconclusive=True, comparable=True,
        asr_before=None, asr_after=None, delta=None,
        by_technique={}, applied_patterns=[],
    )
    if deps is not None:
        new["target"] = deps.settings.target_info()  # inconclusive 여도 온다(계약 v0.2)
    return new


def step_attack_r1(state: RunState, deps: Deps) -> RunState:
    """R1: 스크리닝 18건 → 취약 기법 판정 → 그 기법에만 집중 투입."""
    context = build_context(state)
    assets = state["assets"]
    attacks = list(deps.attacks)

    if deps.settings.full_sweep:
        # 측정 전용 모드: 적응형 샘플링을 끄고 시드 전량을 던진다.
        # 왜 필요한가(2026-08-26): 적응형은 '처방 전에 안 뚫린 기법' 에 집중 투입을 안 한다.
        #   그래서 그 기법은 영원히 n=3(스크리닝)에 갇히고, 처방 후 변화를 통계적으로 판단할 수 없다.
        #   실제로 ROLE·OBFUSC 의 "처방 후 증가"가 3건 중 1건이라 노이즈와 구분이 안 됐다.
        # 제품 동작은 바꾸지 않는다 — 이 플래그는 재측정용이다(속도 목표는 적응형 기준으로 잰다).
        sweep = sorted(attacks, key=lambda a: (a.technique.value, a.id))
        r1_all = run_attacks(sweep, state["target_prompt"], 1, deps, context)
        judge_attempts(r1_all, assets, deps, state.get("persona"), state.get("org"))
        vulnerable: list[Technique] = sorted(
            {a.technique for a in r1_all if a.verdict == Verdict.LEAK}, key=lambda t: t.value
        )
    else:
        screen = screening_set(attacks)
        r1 = run_attacks(screen, state["target_prompt"], 1, deps, context)
        judge_attempts(r1, assets, deps, state.get("persona"), state.get("org"))

        vulnerable = sorted(
            {a.technique for a in r1 if a.verdict == Verdict.LEAK}, key=lambda t: t.value
        )

        seen = {a.attack_id for a in r1}
        concentrate = [a for a in concentration_set(attacks, vulnerable) if a.id not in seen]
        r1c = run_attacks(concentrate, state["target_prompt"], 1, deps, context)
        judge_attempts(r1c, assets, deps, state.get("persona"), state.get("org"))
        r1_all = r1 + r1c
    new: RunState = dict(state)  # type: ignore[assignment]
    new["attempts"] = list(state.get("attempts", [])) + r1_all
    new["vulnerable_techniques"] = vulnerable
    new["r1_attack_ids"] = [a.attack_id for a in r1_all]
    new["round_no"] = 1
    return new


def step_patch(state: RunState, deps: Deps) -> RunState:
    result = assemble_patch(
        state["target_prompt"], list(state.get("vulnerable_techniques", [])), list(deps.patterns),
        list(state.get("assets", [])),
    )
    new: RunState = dict(state)  # type: ignore[assignment]
    new["patched_prompt"] = result.patched_prompt
    new["applied_patterns"] = result.applied_patterns
    return new


def step_attack_r2(state: RunState, deps: Deps) -> RunState:
    """R2: R1 에서 실제로 던진 attack_id 를 그대로 재생(함정①), 처방된 지시문에."""
    context = build_context(state)
    assets = state["assets"]
    by_id = {a.id: a for a in deps.attacks}
    replay = [by_id[i] for i in state["r1_attack_ids"] if i in by_id]
    r2 = run_attacks(replay, state["patched_prompt"], 2, deps, context)
    judge_attempts(r2, assets, deps, state.get("persona"), state.get("org"))

    new: RunState = dict(state)  # type: ignore[assignment]
    new["attempts"] = list(state["attempts"]) + r2
    new["round_no"] = 2
    return new


def step_report(state: RunState, deps: Deps | None = None) -> RunState:
    attempts = state["attempts"]
    r1 = [a for a in attempts if a.round_no == 1]
    r2 = [a for a in attempts if a.round_no == 2]
    report = build_report(r1, r2, state["r1_attack_ids"], list(state.get("applied_patterns", [])))
    new: RunState = dict(state)  # type: ignore[assignment]
    new["report"] = report
    if deps is not None:
        # ★ '무엇을 진단했는가'(계약 v0.2). 등급·ASR 이 보이는 모든 자리에 같이 붙어야 한다 —
        #   모델명 없는 등급은 다른 대상의 결과를 자기 결과로 오독시킨다.
        new["target"] = deps.settings.target_info()
    return new


# ── 순차 실행 ─────────────────────────────────────────────
def run_pipeline(target_prompt: str, deps: Deps, run_id: str = "run_local",
                 recon_state: dict | None = None) -> RunState:
    """진단 1회 전체.

    recon_state: RECON 결과를 미리 계산해 주입한다(assets/persona/org/... 키).
      왜 필요한가 — RECON(gpt-5-mini)은 temperature 고정이 불가능해 실행마다 자산 '이름'이 흔들리고,
      `build_context()` 가 그 이름을 공격문의 {asset} 에 박기 때문에 **공격문 자체가 매번 달라진다.**
      그래서 처방 문구를 바꾼 효과와 RECON 흔들림이 섞여 구분이 안 됐다(2026-08-27 실측: 처방과
      무관한 R1 이 55.9%↔57.9% 로 움직임). 여기에 고정된 RECON 을 주입하면 victim(temp=0)만 남아
      같은 입력이면 같은 결과가 나오고, 처방 변경 1건의 효과가 그대로 신호가 된다.
      실사용 경로(API/CLI)는 None 이라 동작이 바뀌지 않는다 — 측정 전용 주입구다.
    """
    state = new_state(target_prompt, run_id)
    if recon_state is None:
        state = step_recon(state, deps)
    else:
        state = {**state, **recon_state}  # type: ignore[assignment]
    if state.get("inconclusive"):
        return step_inconclusive(state, deps)
    state = step_attack_r1(state, deps)
    state = step_patch(state, deps)
    state = step_attack_r2(state, deps)
    state = step_report(state, deps)
    return state
