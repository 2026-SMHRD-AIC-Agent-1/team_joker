"""오케스트레이션 — POST /api/diagnose 가 부르는 fastapi-free 로직.

prepare(): 입력검증(400) → 프리셋 해석 → 코퍼스 로드 → 프로바이더 조립 →
  프리플라이트 1콜(연결 실패 502) → estimated_calls → run_id/target 확정.
make_worker(): prepare 결과로 '실제 진단 + DB 저장'을 하는 무인자 함수를 만든다(잡 워커가 호출).

★ fastapi 를 import 하지 않는다. app.py 는 이걸 배선만 한다.
★ 프리플라이트를 POST 에서 하는 이유: BYOK 는 잘못된 키로 3~4분·요금을 날리기 전에
  즉시 502 로 알려야 한다(사용자가 고른 설계).
"""

from __future__ import annotations

import datetime
import secrets
from pathlib import Path

from joker.api import presets
from joker.api.serialize import target_block
from joker.corpus.loader import load_default_corpus, load_patterns
from joker.deps import Deps
from joker.pipeline import run_pipeline
from joker.providers.openai_compat import ProviderError
from joker.providers.registry import build_providers
from joker.providers.usage import estimate_calls


def _err(status: int, code: str, message: str) -> dict:
    return {"ok": False, "status": status, "code": code, "message": message}


def prepare(body: dict, base_settings, data_dir: str, user_id: str | None = None) -> dict:
    """user_id 는 로그인 회원의 소유자 키. None 이면 비회원 진단(주인 없음).
    ★ 키워드 인자라 기존 호출부(테스트·스크립트)는 그대로 동작한다 — 계약 v0.3 이 안 깨진다."""
    prompt = (body.get("target_prompt") or "").strip()
    if not prompt:
        return _err(400, "target_prompt_required", "진단할 시스템 프롬프트(target_prompt)가 필요합니다.")

    mode = body.get("mode") or "screening"
    if mode not in ("screening", "full"):
        return _err(400, "bad_mode", "mode 는 screening 또는 full 이어야 합니다.")

    settings, err = presets.resolve_target(body.get("target"), base_settings)
    if err:
        return {"ok": False, **err}
    settings = settings.with_(full_sweep=(mode == "full"))

    dd = Path(data_dir)
    attacks = load_default_corpus(str(dd), run_audit=False)
    patterns = load_patterns(dd.parent / "defenses" / "patterns.yaml")
    providers = build_providers(settings)

    # 프리플라이트 1콜 — BYOK 만. 잘못된 키·엔드포인트로 3~4분·요금을 날리기 전에 즉시 502.
    #   로컬 모델은 콜드 스타트(모델 로딩)가 길어 POST 를 붙잡으면 클라이언트가 타임아웃 난다
    #   (gemma3:4b 첫 호출 15초+). 로컬은 프리플라이트를 생략하고, 연결 실패는 백그라운드 워커가
    #   error(target_unreachable)로 돌려준다 — 요금이 없으니 미리 막을 이유도 없다.
    if settings.target_preset == "byok":
        try:
            providers["victim"].complete(
                system="ping", user="ping",
                temperature=settings.temperature, seed=settings.seed,
            )
        except ProviderError:
            return _err(502, "target_unreachable",
                        "대상 모델 연결에 실패했습니다. base_url·api_key·모델명을 확인하세요.")

    est = estimate_calls(len(attacks), full=settings.full_sweep)

    # ★ 호출 상한이 모자라면 '3분 뒤에' 가 아니라 지금 막는다 (2026-09-09).
    #   적응형 스크리닝은 취약 기법이 많으면 전량까지 올라간다 — 그래서 하한이 아니라
    #   victim_max 로 검사한다(usage.py: "사용자 돈이 걸린 고지를 하한만 말하면 안 된다").
    #   여기서 안 막으면 BudgetExceeded 로 중간에 죽고 그때까지의 결과도 저장되지 않는다.
    if est["victim_max"] > settings.max_calls:
        return _err(400, "budget_too_low",
                    f"이 진단은 대상 모델을 최대 {est['victim_max']}회 호출할 수 있는데 "
                    f"호출 상한이 {settings.max_calls}회입니다. "
                    f"JOKER_MAX_CALLS 를 {est['victim_max']} 이상으로 올리세요.")

    run_id = f"run_{datetime.datetime.now():%Y%m%d_%H%M%S}_{secrets.token_hex(2)}"
    return {
        "ok": True, "run_id": run_id, "settings": settings, "providers": providers,
        "attacks": attacks, "patterns": patterns, "estimated": est,
        "target": target_block(settings.target_info()), "prompt": prompt,
        "user_id": user_id,
    }


def redact_state_responses(state) -> None:
    """저장 직전, 각 attempt.response_raw 에서 RECON 이 찾은 자산 값을 지운다(제자리 변경).

    계약 "response_excerpt 에 비밀값 원문은 오지 않는다" + NFR-DV-002('기본 미저장')의 실체.
    verdict/leak_channel 은 이미 판정이 끝난 상태라 증거 손실이 없다. 리터럴 + 조각 변형까지
    지운다(masking.redact_values). 역순·base64·초성은 규칙 탐지가 leak 으로 잡아 등급에 반영된다.
    """
    from joker.safety.masking import redact_values

    secret_values = [a.value for a in state.get("assets", []) if a.value]
    if not secret_values:
        return
    for at in state.get("attempts", []):
        at.response_raw = redact_values(at.response_raw, secret_values)


def make_worker(prep: dict, repo):
    """진단 실행 + 저장을 하는 무인자 함수. 여기서만 SQLite 에 쓴다(잡 워커 스레드)."""
    settings = prep["settings"]
    providers = prep["providers"]

    def _work() -> None:
        deps = Deps(
            settings=settings,
            victim=providers["victim"], recon=providers["recon"], judge=providers["judge"],
            attacks=tuple(prep["attacks"]), patterns=tuple(prep["patterns"]),
        )
        state = run_pipeline(prep["prompt"], deps, run_id=prep["run_id"])
        redact_state_responses(state)  # ★ 저장 전 자산값 마스킹(사용자 결정 0831)
        # 재현 맥락(SPEC §4) — target 을 파이프라인이 이미 넣지만, 옛 키 폴백도 채워둔다.
        state["env_profile"] = settings.env_profile
        state["backend"] = settings.backend_for("victim")
        state["victim_model"] = settings.victim_model
        # ★ 소유자. 이 값이 있어야 GET/DELETE 가 남의 진단을 걸러낼 수 있다(IDOR 차단의 근거).
        state["user_id"] = prep.get("user_id")
        repo.init_schema()
        repo.save_run(state)

    return _work
